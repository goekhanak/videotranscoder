/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon Cloud Watch Java Library
 *  API Version: 2009-05-15
 *  Generated: Sat May 16 23:33:49 PDT 2009 
 * 
 */



package com.amazonaws.cloudwatch.samples;

import java.util.List;
import java.util.ArrayList;
import com.amazonaws.cloudwatch.*;
import com.amazonaws.cloudwatch.model.*;
import com.amazonaws.cloudwatch.mock.AmazonCloudWatchMock;

/**
 *
 * List Metrics  Samples
 *
 *
 */
public class ListMetricsSample {

    /**
     * Just add few required parameters, and try the service
     * List Metrics functionality
     *
     * @param args unused
     */
    public static void main(String... args) {
        
        /************************************************************************
         * Access Key ID and Secret Acess Key ID, obtained from:
         * http://aws.amazon.com
         ***********************************************************************/
        String accessKeyId = "<Your Access Key ID>";
        String secretAccessKey = "<Your Secret Access Key>";

        /************************************************************************
         * Instantiate Http Client Implementation of Amazon Cloud Watch 
         ***********************************************************************/
        AmazonCloudWatch service = new AmazonCloudWatchClient(accessKeyId, secretAccessKey);
        
        /************************************************************************
         * Uncomment to try advanced configuration options. Available options are:
         *
         *  - Signature Version
         *  - Proxy Host and Proxy Port
         *  - Service URL
         *  - User Agent String to be sent to Amazon Cloud Watch   service
         *
         ***********************************************************************/
        // AmazonCloudWatchConfig config = new AmazonCloudWatchConfig();
        // config.setSignatureVersion("0");
        // AmazonCloudWatch service = new AmazonCloudWatchClient(accessKeyId, secretAccessKey, config);
 
        /************************************************************************
         * Uncomment to try out Mock Service that simulates Amazon Cloud Watch 
         * responses without calling Amazon Cloud Watch  service.
         *
         * Responses are loaded from local XML files. You can tweak XML files to
         * experiment with various outputs during development
         *
         * XML files available under com/amazonaws/cloudwatch/mock tree
         *
         ***********************************************************************/
        // AmazonCloudWatch service = new AmazonCloudWatchMock();

        /************************************************************************
         * Setup request parameters and uncomment invoke to try out 
         * sample for List Metrics 
         ***********************************************************************/
         ListMetricsRequest request = new ListMetricsRequest();
        
         // @TODO: set request parameters here

         // invokeListMetrics(service, request);

    }


                
    /**
     * List Metrics  request sample
  
     * @param service instance of AmazonCloudWatch service
     * @param request Action to invoke
     */
    public static void invokeListMetrics(AmazonCloudWatch service, ListMetricsRequest request) {
        try {
            
            ListMetricsResponse response = service.listMetrics(request);

            
            System.out.println ("ListMetrics Action Response");
            System.out.println ("=============================================================================");
            System.out.println ();

            System.out.println("    ListMetricsResponse");
            System.out.println();
            if (response.isSetListMetricsResult()) {
                System.out.println("        ListMetricsResult");
                System.out.println();
                ListMetricsResult  listMetricsResult = response.getListMetricsResult();
                java.util.List<Metric> metricsList = listMetricsResult.getMetrics();
                for (Metric metrics : metricsList) {
                    System.out.println("            Metrics");
                    System.out.println();
                    if (metrics.isSetMeasureName()) {
                        System.out.println("                MeasureName");
                        System.out.println();
                        System.out.println("                    " + metrics.getMeasureName());
                        System.out.println();
                    }
                    java.util.List<Dimension> dimensionsList = metrics.getDimensions();
                    for (Dimension dimensions : dimensionsList) {
                        System.out.println("                Dimensions");
                        System.out.println();
                        if (dimensions.isSetName()) {
                            System.out.println("                    Name");
                            System.out.println();
                            System.out.println("                        " + dimensions.getName());
                            System.out.println();
                        }
                        if (dimensions.isSetValue()) {
                            System.out.println("                    Value");
                            System.out.println();
                            System.out.println("                        " + dimensions.getValue());
                            System.out.println();
                        }
                    }
                    if (metrics.isSetNamespace()) {
                        System.out.println("                Namespace");
                        System.out.println();
                        System.out.println("                    " + metrics.getNamespace());
                        System.out.println();
                    }
                }
                if (listMetricsResult.isSetNextToken()) {
                    System.out.println("            NextToken");
                    System.out.println();
                    System.out.println("                " + listMetricsResult.getNextToken());
                    System.out.println();
                }
            } 
            if (response.isSetResponseMetadata()) {
                System.out.println("        ResponseMetadata");
                System.out.println();
                ResponseMetadata  responseMetadata = response.getResponseMetadata();
                if (responseMetadata.isSetRequestId()) {
                    System.out.println("            RequestId");
                    System.out.println();
                    System.out.println("                " + responseMetadata.getRequestId());
                    System.out.println();
                }
            } 
            System.out.println();

           
        } catch (AmazonCloudWatchException ex) {
            
            System.out.println("Caught Exception: " + ex.getMessage());
            System.out.println("Response Status Code: " + ex.getStatusCode());
            System.out.println("Error Code: " + ex.getErrorCode());
            System.out.println("Error Type: " + ex.getErrorType());
            System.out.println("Request ID: " + ex.getRequestId());
            System.out.print("XML: " + ex.getXML());
        }
    }
        
}
