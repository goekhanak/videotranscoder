/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon Cloud Watch Java Library
 *  API Version: 2009-05-15
 *  Generated: Sat May 16 23:33:49 PDT 2009 
 * 
 */



package com.amazonaws.cloudwatch.samples;

import java.util.List;
import java.util.ArrayList;
import com.amazonaws.cloudwatch.*;
import com.amazonaws.cloudwatch.model.*;
import com.amazonaws.cloudwatch.mock.AmazonCloudWatchMock;

/**
 *
 * Get Metric Statistics  Samples
 *
 *
 */
public class GetMetricStatisticsSample {

    /**
     * Just add few required parameters, and try the service
     * Get Metric Statistics functionality
     *
     * @param args unused
     */
    public static void main(String... args) {
        
        /************************************************************************
         * Access Key ID and Secret Acess Key ID, obtained from:
         * http://aws.amazon.com
         ***********************************************************************/
        String accessKeyId = "<Your Access Key ID>";
        String secretAccessKey = "<Your Secret Access Key>";

        /************************************************************************
         * Instantiate Http Client Implementation of Amazon Cloud Watch 
         ***********************************************************************/
        AmazonCloudWatch service = new AmazonCloudWatchClient(accessKeyId, secretAccessKey);
        
        /************************************************************************
         * Uncomment to try advanced configuration options. Available options are:
         *
         *  - Signature Version
         *  - Proxy Host and Proxy Port
         *  - Service URL
         *  - User Agent String to be sent to Amazon Cloud Watch   service
         *
         ***********************************************************************/
        // AmazonCloudWatchConfig config = new AmazonCloudWatchConfig();
        // config.setSignatureVersion("0");
        // AmazonCloudWatch service = new AmazonCloudWatchClient(accessKeyId, secretAccessKey, config);
 
        /************************************************************************
         * Uncomment to try out Mock Service that simulates Amazon Cloud Watch 
         * responses without calling Amazon Cloud Watch  service.
         *
         * Responses are loaded from local XML files. You can tweak XML files to
         * experiment with various outputs during development
         *
         * XML files available under com/amazonaws/cloudwatch/mock tree
         *
         ***********************************************************************/
        // AmazonCloudWatch service = new AmazonCloudWatchMock();

        /************************************************************************
         * Setup request parameters and uncomment invoke to try out 
         * sample for Get Metric Statistics 
         ***********************************************************************/
         GetMetricStatisticsRequest request = new GetMetricStatisticsRequest();
        
         // @TODO: set request parameters here

         // invokeGetMetricStatistics(service, request);

    }


                    
    /**
     * Get Metric Statistics  request sample
  
     * @param service instance of AmazonCloudWatch service
     * @param request Action to invoke
     */
    public static void invokeGetMetricStatistics(AmazonCloudWatch service, GetMetricStatisticsRequest request) {
        try {
            
            GetMetricStatisticsResponse response = service.getMetricStatistics(request);

            
            System.out.println ("GetMetricStatistics Action Response");
            System.out.println ("=============================================================================");
            System.out.println ();

            System.out.println("    GetMetricStatisticsResponse");
            System.out.println();
            if (response.isSetResponseMetadata()) {
                System.out.println("        ResponseMetadata");
                System.out.println();
                ResponseMetadata  responseMetadata = response.getResponseMetadata();
                if (responseMetadata.isSetRequestId()) {
                    System.out.println("            RequestId");
                    System.out.println();
                    System.out.println("                " + responseMetadata.getRequestId());
                    System.out.println();
                }
            } 
            if (response.isSetGetMetricStatisticsResult()) {
                System.out.println("        GetMetricStatisticsResult");
                System.out.println();
                GetMetricStatisticsResult  getMetricStatisticsResult = response.getGetMetricStatisticsResult();
                java.util.List<Datapoint> datapointsList = getMetricStatisticsResult.getDatapoints();
                for (Datapoint datapoints : datapointsList) {
                    System.out.println("            Datapoints");
                    System.out.println();
                    if (datapoints.isSetTimestamp()) {
                        System.out.println("                Timestamp");
                        System.out.println();
                        System.out.println("                    " + datapoints.getTimestamp());
                        System.out.println();
                    }
                    if (datapoints.isSetSamples()) {
                        System.out.println("                Samples");
                        System.out.println();
                        System.out.println("                    " + datapoints.getSamples());
                        System.out.println();
                    }
                    if (datapoints.isSetAverage()) {
                        System.out.println("                Average");
                        System.out.println();
                        System.out.println("                    " + datapoints.getAverage());
                        System.out.println();
                    }
                    if (datapoints.isSetSum()) {
                        System.out.println("                Sum");
                        System.out.println();
                        System.out.println("                    " + datapoints.getSum());
                        System.out.println();
                    }
                    if (datapoints.isSetMinimum()) {
                        System.out.println("                Minimum");
                        System.out.println();
                        System.out.println("                    " + datapoints.getMinimum());
                        System.out.println();
                    }
                    if (datapoints.isSetMaximum()) {
                        System.out.println("                Maximum");
                        System.out.println();
                        System.out.println("                    " + datapoints.getMaximum());
                        System.out.println();
                    }
                    if (datapoints.isSetUnit()) {
                        System.out.println("                Unit");
                        System.out.println();
                        System.out.println("                    " + datapoints.getUnit());
                        System.out.println();
                    }
                    if (datapoints.isSetCustomUnit()) {
                        System.out.println("                CustomUnit");
                        System.out.println();
                        System.out.println("                    " + datapoints.getCustomUnit());
                        System.out.println();
                    }
                }
                if (getMetricStatisticsResult.isSetLabel()) {
                    System.out.println("            Label");
                    System.out.println();
                    System.out.println("                " + getMetricStatisticsResult.getLabel());
                    System.out.println();
                }
            } 
            System.out.println();

           
        } catch (AmazonCloudWatchException ex) {
            
            System.out.println("Caught Exception: " + ex.getMessage());
            System.out.println("Response Status Code: " + ex.getStatusCode());
            System.out.println("Error Code: " + ex.getErrorCode());
            System.out.println("Error Type: " + ex.getErrorType());
            System.out.println("Request ID: " + ex.getRequestId());
            System.out.print("XML: " + ex.getXML());
        }
    }
    
}
