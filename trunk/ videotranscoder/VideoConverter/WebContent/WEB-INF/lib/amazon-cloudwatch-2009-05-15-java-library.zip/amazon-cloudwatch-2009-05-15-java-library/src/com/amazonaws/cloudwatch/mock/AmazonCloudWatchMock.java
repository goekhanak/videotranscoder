/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon Cloud Watch Java Library
 *  API Version: 2009-05-15
 *  Generated: Sat May 16 23:33:49 PDT 2009 
 * 
 */



package com.amazonaws.cloudwatch.mock;

import com.amazonaws.cloudwatch.model.*;
import com.amazonaws.cloudwatch.*;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.InputSource;

/**
 *
 * AmazonCloudWatchMock is the implementation of AmazonCloudWatch based
 * on the pre-populated set of XML files that serve local data. It simulates
 * responses from Amazon Cloud Watch service.
 *
 * Use this to test your application without making a call to Amazon Cloud Watch 
 *
 * Note, current Mock Service implementation does not valiadate requests
 *
 */
public  class AmazonCloudWatchMock implements AmazonCloudWatch {

    private final Log log = LogFactory.getLog(AmazonCloudWatchMock.class);
    private static JAXBContext  jaxbContext;
    private static ThreadLocal<Unmarshaller> unmarshaller;


    /** Initialize JAXBContext and  Unmarshaller **/
    static {
        try {
            jaxbContext = JAXBContext.newInstance("com.amazonaws.cloudwatch.model", AmazonCloudWatch.class.getClassLoader());
        } catch (JAXBException ex) {
            throw new ExceptionInInitializerError(ex);
        }
        unmarshaller = new ThreadLocal<Unmarshaller>() {
            protected synchronized Unmarshaller initialValue() {
                try {
                    return jaxbContext.createUnmarshaller();
                } catch(JAXBException e) {
                    throw new ExceptionInInitializerError(e);
                }
            }
        };
    }

    // Public API ------------------------------------------------------------//

    
    /**
     * List Metrics 
     *

     * @param request
     *          ListMetrics Action
     * @return
     *          ListMetrics Response from the service
     *
     * @throws AmazonCloudWatchException
     */
    public ListMetricsResponse listMetrics(ListMetricsRequest request)
        throws AmazonCloudWatchException {
        ListMetricsResponse response;
        try {
            response = (ListMetricsResponse)getUnmarshaller().unmarshal
                    (new InputSource(this.getClass().getResourceAsStream("ListMetricsResponse.xml")));

            log.debug("Response from Mock Service: " + response.toXML());

        } catch (JAXBException jbe) {
            throw new AmazonCloudWatchException("Unable to process mock response", jbe);
        }
        return response;
    }

    
    /**
     * Get Metric Statistics 
     *

     * @param request
     *          GetMetricStatistics Action
     * @return
     *          GetMetricStatistics Response from the service
     *
     * @throws AmazonCloudWatchException
     */
    public GetMetricStatisticsResponse getMetricStatistics(GetMetricStatisticsRequest request)
        throws AmazonCloudWatchException {
        GetMetricStatisticsResponse response;
        try {
            response = (GetMetricStatisticsResponse)getUnmarshaller().unmarshal
                    (new InputSource(this.getClass().getResourceAsStream("GetMetricStatisticsResponse.xml")));

            log.debug("Response from Mock Service: " + response.toXML());

        } catch (JAXBException jbe) {
            throw new AmazonCloudWatchException("Unable to process mock response", jbe);
        }
        return response;
    }


    /**
     * Get unmarshaller for current thread
     */
    private Unmarshaller getUnmarshaller() {
        return unmarshaller.get();
    }
}