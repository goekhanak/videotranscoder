/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon Cloud Watch Java Library
 *  API Version: 2009-05-15
 *  Generated: Sat May 16 23:33:49 PDT 2009 
 * 
 */



package com.amazonaws.cloudwatch;

import com.amazonaws.cloudwatch.model.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;


/**

 *
 */
public class AmazonCloudWatchAsyncClient extends AmazonCloudWatchClient implements AmazonCloudWatchAsync {

    private ExecutorService executor;

    /**
     * Client to make asynchronous calls to the service. Please note, you should
     * configure executor with same number of concurrent threads as number of
     * http connections specified in AmazonCloudWatchConfig. Default number of
     * max http connections is 100.
     *
     * @param awsAccessKeyId AWS Access Key Id
     * @param awsSecretAccessKey AWS Secret Key
     * @param config service configuration. Pass new AmazonCloudWatchConfig() if you
     * plan to use defaults
     *
     * @param executor Executor service to manage asynchronous calls.
     *
     */
    public AmazonCloudWatchAsyncClient(String awsAccessKeyId, String awsSecretAccessKey,
            AmazonCloudWatchConfig config, ExecutorService executor) {
        super(awsAccessKeyId, awsSecretAccessKey, config);
        this.executor = executor;
    }

        

    /**
     * Non-blocking List Metrics 
     * <p/>
     * Returns <code>future</code> pointer to ListMetricsResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return ListMetricsResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonCloudWatchException can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;ListMetricsResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;ListMetricsResponse&gt;&gt;();
     *  for (ListMetricsRequest request : requests) {
     *      responses.add(client.listMetricsAsync(request));
     *  }
     *  for (Future&lt;ListMetricsResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          ListMetricsResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonCloudWatchException) {
     *              AmazonCloudWatchException exception = AmazonCloudWatchException.class.cast(e);
     *          // handle AmazonCloudWatchException
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          ListMetricsRequest request
     * @return Future&lt;ListMetricsResponse&gt; future pointer to ListMetricsResponse
     * 
     */
    public Future<ListMetricsResponse> listMetricsAsync(final ListMetricsRequest request) {
        Future<ListMetricsResponse> response = executor.submit(new Callable<ListMetricsResponse>() {

            public ListMetricsResponse call() throws AmazonCloudWatchException {
                return listMetrics(request);
            }
        });
        return response;
    }


        

    /**
     * Non-blocking Get Metric Statistics 
     * <p/>
     * Returns <code>future</code> pointer to GetMetricStatisticsResponse
     * <p/>
     * If response is ready, call to <code>future.get()</code> 
     * will return GetMetricStatisticsResponse. 
     * <p/>
     * If response is not ready, call to <code>future.get()</code> will block the 
     * calling thread until response is returned. 
     * <p/>
     * Note, <code>future.get()</code> will throw wrapped runtime exception. 
     * <p/>
     * If service error has occured, AmazonCloudWatchException can be extracted with
     * <code>exception.getCause()</code>
     * <p/>
     * Usage example for parallel processing:
     * <pre>
     *
     *  List&lt;Future&lt;GetMetricStatisticsResponse&gt;&gt; responses = new ArrayList&lt;Future&lt;GetMetricStatisticsResponse&gt;&gt;();
     *  for (GetMetricStatisticsRequest request : requests) {
     *      responses.add(client.getMetricStatisticsAsync(request));
     *  }
     *  for (Future&lt;GetMetricStatisticsResponse&gt; future : responses) {
     *      while (!future.isDone()) {
     *          Thread.yield();
     *      }
     *      try {
     *          GetMetricStatisticsResponse response = future.get();
     *      // use response
     *      } catch (Exception e) {
     *          if (e instanceof AmazonCloudWatchException) {
     *              AmazonCloudWatchException exception = AmazonCloudWatchException.class.cast(e);
     *          // handle AmazonCloudWatchException
     *          } else {
     *          // handle other exceptions
     *          }
     *      }
     *  }
     * </pre>
     *
     * @param request
     *          GetMetricStatisticsRequest request
     * @return Future&lt;GetMetricStatisticsResponse&gt; future pointer to GetMetricStatisticsResponse
     * 
     */
    public Future<GetMetricStatisticsResponse> getMetricStatisticsAsync(final GetMetricStatisticsRequest request) {
        Future<GetMetricStatisticsResponse> response = executor.submit(new Callable<GetMetricStatisticsResponse>() {

            public GetMetricStatisticsResponse call() throws AmazonCloudWatchException {
                return getMetricStatistics(request);
            }
        });
        return response;
    }


}
