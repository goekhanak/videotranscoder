
package com.amazonaws.cloudwatch.model;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.amazonaws.cloudwatch.model package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.amazonaws.cloudwatch.model
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Datapoint }
     * 
     */
    public Datapoint createDatapoint() {
        return new Datapoint();
    }

    /**
     * Create an instance of {@link Error }
     * 
     */
    public Error createError() {
        return new Error();
    }

    /**
     * Create an instance of {@link GetMetricStatisticsRequest }
     * 
     */
    public GetMetricStatisticsRequest createGetMetricStatisticsRequest() {
        return new GetMetricStatisticsRequest();
    }

    /**
     * Create an instance of {@link Dimension }
     * 
     */
    public Dimension createDimension() {
        return new Dimension();
    }

    /**
     * Create an instance of {@link ResponseMetadata }
     * 
     */
    public ResponseMetadata createResponseMetadata() {
        return new ResponseMetadata();
    }

    /**
     * Create an instance of {@link GetMetricStatisticsResponse }
     * 
     */
    public GetMetricStatisticsResponse createGetMetricStatisticsResponse() {
        return new GetMetricStatisticsResponse();
    }

    /**
     * Create an instance of {@link Metric }
     * 
     */
    public Metric createMetric() {
        return new Metric();
    }

    /**
     * Create an instance of {@link Error.Detail }
     * 
     */
    public Error.Detail createErrorDetail() {
        return new Error.Detail();
    }

    /**
     * Create an instance of {@link GetMetricStatisticsResult }
     * 
     */
    public GetMetricStatisticsResult createGetMetricStatisticsResult() {
        return new GetMetricStatisticsResult();
    }

    /**
     * Create an instance of {@link ListMetricsRequest }
     * 
     */
    public ListMetricsRequest createListMetricsRequest() {
        return new ListMetricsRequest();
    }

    /**
     * Create an instance of {@link ListMetricsResult }
     * 
     */
    public ListMetricsResult createListMetricsResult() {
        return new ListMetricsResult();
    }

    /**
     * Create an instance of {@link ListMetricsResponse }
     * 
     */
    public ListMetricsResponse createListMetricsResponse() {
        return new ListMetricsResponse();
    }

    /**
     * Create an instance of {@link ErrorResponse }
     * 
     */
    public ErrorResponse createErrorResponse() {
        return new ErrorResponse();
    }

}
