/******************************************************************************* 
 *  Copyright 2008 Amazon Technologies, Inc.
 *  Licensed under the Apache License, Version 2.0 (the "License"); 
 *  
 *  You may not use this file except in compliance with the License. 
 *  You may obtain a copy of the License at: http://aws.amazon.com/apache2.0
 *  This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR 
 *  CONDITIONS OF ANY KIND, either express or implied. See the License for the 
 *  specific language governing permissions and limitations under the License.
 * ***************************************************************************** 
 *    __  _    _  ___ 
 *   (  )( \/\/ )/ __)
 *   /__\ \    / \__ \
 *  (_)(_) \/\/  (___/
 * 
 *  Amazon Cloud Watch Java Library
 *  API Version: 2009-05-15
 *  Generated: Sat May 16 23:33:49 PDT 2009 
 * 
 */



package com.amazonaws.cloudwatch.samples;

import java.util.List;
import java.util.ArrayList;
import com.amazonaws.cloudwatch.*;
import com.amazonaws.cloudwatch.model.*;
import java.util.concurrent.Future;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;

/**
 *
 * Get Metric Statistics  Samples
 *
 *
 */
public class GetMetricStatisticsAsyncSample {

    /**
     * Just add few required parameters, and try the service
     * Get Metric Statistics functionality
     *
     * @param args unused
     */
    public static void main(String... args) {
        
        /************************************************************************
         * Access Key ID and Secret Acess Key ID, obtained from:
         * http://aws.amazon.com
         ***********************************************************************/
         String accessKeyId = "<Your Access Key ID>";
         String secretAccessKey = "<Your Secret Access Key>";

        /************************************************************************
         * Instantiate Http Client Implementation of Amazon Cloud Watch 
         * 
         * Important! Number of threads in executor should match number of connections
         * for http client.
         *
         ***********************************************************************/

         AmazonCloudWatchConfig config = new AmazonCloudWatchConfig().withMaxConnections (100);
         ExecutorService executor = Executors.newFixedThreadPool(100);
         AmazonCloudWatchAsync service = new AmazonCloudWatchAsyncClient(accessKeyId, secretAccessKey, config, executor);

        /************************************************************************
         * Setup requests parameters and invoke parallel processing. Of course
         * in real world application, there will be much more than a couple of
         * requests to process.
         ***********************************************************************/
         GetMetricStatisticsRequest requestOne = new GetMetricStatisticsRequest();
         // @TODO: set request parameters here

         GetMetricStatisticsRequest requestTwo = new GetMetricStatisticsRequest();
         // @TODO: set second request parameters here

         List<GetMetricStatisticsRequest> requests = new ArrayList<GetMetricStatisticsRequest>();
         requests.add(requestOne);
         requests.add(requestTwo);

         invokeGetMetricStatistics(service, requests);

         executor.shutdown();

    }


                    
    /**
     * Get Metric Statistics request sample
  
     * @param service instance of AmazonCloudWatch service
     * @param requests list of requests to process
     */
    public static void invokeGetMetricStatistics(AmazonCloudWatchAsync service, List<GetMetricStatisticsRequest> requests) {
        List<Future<GetMetricStatisticsResponse>> responses = new ArrayList<Future<GetMetricStatisticsResponse>>();
        for (GetMetricStatisticsRequest request : requests) {
            responses.add(service.getMetricStatisticsAsync(request));
        }
        for (Future<GetMetricStatisticsResponse> future : responses) {
            while (!future.isDone()) {
                Thread.yield();
            }
            try {
                GetMetricStatisticsResponse response = future.get();
                // Original request corresponding to this response, if needed:
                GetMetricStatisticsRequest originalRequest = requests.get(responses.indexOf(future));
                System.out.println("Response request id: " + response.getResponseMetadata().getRequestId());
            } catch (Exception e) {
                if (e.getCause() instanceof AmazonCloudWatchException) {
                    AmazonCloudWatchException exception = AmazonCloudWatchException.class.cast(e.getCause());
                    System.out.println("Caught Exception: " + exception.getMessage());
                    System.out.println("Response Status Code: " + exception.getStatusCode());
                    System.out.println("Error Code: " + exception.getErrorCode());
                    System.out.println("Error Type: " + exception.getErrorType());
                    System.out.println("Request ID: " + exception.getRequestId());
                    System.out.print("XML: " + exception.getXML());
                } else {
                    e.printStackTrace();
                }
            }
        }
    }
    
}
