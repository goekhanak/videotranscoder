@javax.xml.bind.annotation.XmlSchema(namespace = "http://monitoring.amazonaws.com/doc/2009-05-15/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.amazonaws.cloudwatch.model;
